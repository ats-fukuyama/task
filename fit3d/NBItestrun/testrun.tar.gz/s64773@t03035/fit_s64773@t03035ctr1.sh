#!/bin/csh
#  
 rm prof.out20
 ln -s s64773@t03035ctr1.out20 prof.out20
 read20_050323.lm < fit_s64773@t03035ctr1.in  > fit_s64773@t03035ctr1.out 
 mv prof.out10  fit_s64773@t03035ctr1.out10 
 mv prof.out11  fit_s64773@t03035ctr1.out11 
 rm prof.out20
