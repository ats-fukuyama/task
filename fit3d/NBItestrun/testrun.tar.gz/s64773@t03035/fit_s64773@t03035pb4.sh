#!/bin/csh
#  
 rm prof.out20
 ln -s s64773@t03035pb4.out20 prof.out20
 read20_050323.lm < fit_s64773@t03035pb4.in  > fit_s64773@t03035pb4.out 
 cp prof.out10  fit_pb4.out10 
 mv prof.out10  fit_s64773@t03035pb4.out10 
 mv prof.out11  fit_s64773@t03035pb4.out11 
 rm prof.out20
 ln -s s64773@t03035pb4.out30 prof.out20
 read20_050323.lm < fit_s64773@t03035pb4.in  > fit_s64773@t03035pb4.out 
 cp prof.out10  fit_pb4.out20 
 mv prof.out10  fit_s64773@t03035pb4.out20 
 mv prof.out11  fit_s64773@t03035pb4.out21 
 rm prof.out20
 ln -s s64773@t03035pb4.out40 prof.out20
 read20_050323.lm < fit_s64773@t03035pb4.in  > fit_s64773@t03035pb4.out 
 cp prof.out10  fit_pb4.out30 
 mv prof.out10  fit_s64773@t03035pb4.out30 
 mv prof.out11  fit_s64773@t03035pb4.out31 
 rm prof.out20
 depsum_070416.lm 
 mv fit_pb4.out40  fit_s64773@t03035pb4.out40 
 rm fit_pb4.*
