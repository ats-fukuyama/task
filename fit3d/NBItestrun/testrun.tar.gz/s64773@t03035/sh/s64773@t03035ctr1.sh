#!/bin/csh
 setenv F_PROGINF DETAIL
 setenv F_UFMTIEEE 10
#  
 setenv F_FF10 /lhdwork/murakami/nbidb/Rax360/boz10.r360q100b004a8020.dat  
 setenv F_FF06 /short/murakami/s64773@t03035/s64773@t03035ctr1.out6
 setenv F_FF07 /short/murakami/s64773@t03035/s64773@t03035ctr1.out7
 setenv F_FF08 /short/murakami/s64773@t03035/s64773@t03035ctr1.ps
 setenv F_FF09 /short/murakami/s64773@t03035/s64773@t03035ctr1.out9
 setenv F_FF15 /short/murakami/s64773@t03035/s64773@t03035ctr1.out15
 setenv F_FF21 /short/murakami/s64773@t03035/s64773@t03035ctr1.out21
 setenv F_FF05 /short/murakami/s64773@t03035/sh/s64773@t03035ctr1.in
#  
 time /long/murakami/nbidb/go/hfreya2_020502.lm
#  
#  
 setenv F_FF11 /dev/null
 setenv F_FF12 /dev/null
 setenv F_FF14 /dev/null
 setenv F_FF16 /long/murakami/mcnbi/init/aurora.fu08
 setenv F_FF20 /short/murakami/s64773@t03035/s64773@t03035ctr1.out20
 setenv F_FF30 /short/murakami/s64773@t03035/s64773@t03035ctr1.out30
 setenv F_FF40 /short/murakami/s64773@t03035/s64773@t03035ctr1.out40
 setenv F_FF06 /short/murakami/s64773@t03035/mcnbi_s64773@t03035ctr1.out
 setenv F_FF05 /short/murakami/s64773@t03035/sh/mcnbi_s64773@t03035ctr1.in
#  
 time /long/murakami/nbidb/go/mcnbi_LHDstd_N1000_040527pb.lm
